import java.util.Scanner;
public class Banco {
    Scanner sc = new Scanner(System.in);

    public ContaBancaria [] ContasBancarias;

    public Banco(ContaBancaria[] contasBancarias) {
        ContasBancarias = contasBancarias;
    }

    void mostrarContas(){
        System.out.println("Contas existentes no banco: ");
        for (ContaBancaria ContaBancaria : ContasBancarias) {
            System.out.println(ContaBancaria);
        }
    }

    public void exibirSaldo(){
        for(ContaBancaria conta : ContasBancarias){

            System.out.println(conta);
        }
    }

    public void CalcularSaldoTotal(){
        double soma = 0;
        for(ContaBancaria conta : ContasBancarias){
            soma += conta.saldo;
        }
        System.out.println("Saldo total de todas as contas: " + soma);
    }

    void transferencia(ContaBancaria contaOrigem, ContaBancaria contaDestino, double valor){
        if(contaOrigem.saldo >= valor){
            contaOrigem.saldo = contaOrigem.saldo - valor;
            contaDestino.saldo = contaDestino.saldo += valor;
        }else{
            System.err.println("Saldo insuficiente.");
        }
    }

    /*public void Transferir(){
        System.out.println("Transferência");
        int idconta = 0;
        System.out.println("Qual sua conta?");
        for(ContaBancaria conta : ContasBancarias){
            idconta ++;
            System.out.println("Conta do: " + conta.nome + "(" +idconta+ ")");
        }
        System.out.println("Digite o número correspondente a sua conta: ");
        int escolha = sc.nextInt();
        switch (escolha)    {
            case 1: System.out.println("Para quem deseja transferir?");
            idconta = 0;
        for(ContaBancaria conta : ContasBancarias){
            idconta ++;
            System.out.println("Conta do: " + conta.nome + "(" +idconta+ ")");
        }
        escolha = sc.nextInt();
        switch (escolha) {
            case 1: System.out.println("Você não pode transferir para si mesmo.");
            break;
        case 2: System.out.println("Quanto deseja transferir?");
        double valor = sc.nextDouble();
        if (valor > ContasBancarias[0].saldo){
            System.out.println("Saldo insuficiente.");
            break;
        } else {
            ContasBancarias[1].saldo = ContasBancarias[1].saldo + valor;
            ContasBancarias[0].saldo = ContasBancarias[0].saldo - valor;
            System.out.println("Transferência concluída!");
            System.out.println("Saldo atual: " + ContasBancarias[0].saldo);
            break;
        }
                        }
        case 2: System.out.println("Para quem deseja transferir?");
        idconta = 0;
    for(ContaBancaria conta : ContasBancarias){
        idconta ++;
        System.out.println("Conta do: " + conta.nome + "(" +idconta+ ")");
    }
    escolha = sc.nextInt();
    switch (escolha) {
        case 1: System.out.println("Quanto deseja transferir?");
        double valor = sc.nextDouble();
        if (valor > ContasBancarias[0].saldo){
            System.out.println("Saldo insuficiente.");
            break;
        } else {
            ContasBancarias[1].saldo = ContasBancarias[1].saldo + valor;
            ContasBancarias[0].saldo = ContasBancarias[0].saldo - valor;
            System.out.println("Transferência concluída!");
            System.out.println("Saldo atual: " + ContasBancarias[0].saldo);
            break;
            
                                }
    case 2: System.out.println("Você não pode transferir para si mesmo.");
    break;
    }
        }
            }*/

}
