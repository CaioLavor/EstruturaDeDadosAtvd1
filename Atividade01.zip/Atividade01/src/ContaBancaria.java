public class ContaBancaria {
    public double saldo;
    public int numeroConta;
    public String nome;
    
    public ContaBancaria(double saldo, int numeroConta, String nome) {
        this.saldo = saldo;
        this.numeroConta = numeroConta;
        this.nome = nome;
    }
    
   /* public double getSaldo() {
        return saldo;
    }*/

    /* public int getNumeroConta() {
        return numeroConta;
    }*/

    @Override
    public String toString() {
        return "Conta \n" +
                "Saldo: " + this.saldo +
                " Nome: " + this.nome +
                " Número da Conta: " + this.numeroConta;
    }
}
