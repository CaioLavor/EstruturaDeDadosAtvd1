public class App {
    public static void main(String[] args) throws Exception {
        ContaBancaria conta1 = new ContaBancaria(1000, 1234, "Caio");
        ContaBancaria conta2 = new ContaBancaria(2000, 1235, "Bruna");
        
        ContaBancaria [] contas = {conta1, conta2};
        
        Banco banco = new Banco(contas);

        banco.exibirSaldo();

        banco.CalcularSaldoTotal();

        //banco.Transferir();

        banco.transferencia(conta1, conta2, 500);
        banco.mostrarContas();

    }
}
